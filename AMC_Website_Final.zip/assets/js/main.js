
const langToggle = document.getElementById('lang-toggle');
let isEnglish = true;
langToggle.addEventListener('click', () => {
  document.querySelectorAll('[data-en]').forEach(el => {
    el.textContent = isEnglish ? el.getAttribute('data-mn') : el.getAttribute('data-en');
  });
  isEnglish = !isEnglish;
});
